# Cognitomap
The project develops an automated question classification system using Bloom’s Taxonomy. It features PDF question paper upload, AI/ML classification with a sentence transformer, Pinecone for vector storage, and MongoDB for data storage. Chart.js generates analytics and reports, enhancing educational insights.
